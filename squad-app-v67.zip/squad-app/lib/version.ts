// Mantenha em sincronia com package.json -> "version".
export const APP_VERSION = "0.67.0";
export const APP_NAME = "{V.AI.be} Cielo";
